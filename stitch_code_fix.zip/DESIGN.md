---
name: Repository Repair Console
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#434655'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#006329'
  on-tertiary: '#ffffff'
  tertiary-container: '#007f36'
  on-tertiary-container: '#c7ffca'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#7ffc97'
  tertiary-fixed-dim: '#62df7d'
  on-tertiary-fixed: '#002109'
  on-tertiary-fixed-variant: '#005320'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Geist
    fontSize: 2rem
    fontWeight: '600'
    lineHeight: 2.5rem
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Geist
    fontSize: 1.625rem
    fontWeight: '600'
    lineHeight: 2.125rem
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Geist
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.025em
  headline-md:
    fontFamily: Geist
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Geist
    fontSize: 1rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: -0.015em
  body-lg:
    fontFamily: Geist
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.625rem
    letterSpacing: -0.01em
  body-md:
    fontFamily: Geist
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Geist
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.125rem
  label-code-md:
    fontFamily: JetBrains Mono
    fontSize: 0.8125rem
    fontWeight: '500'
    lineHeight: 1.375rem
    letterSpacing: -0.01em
  label-code-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: 0em
  label-badge:
    fontFamily: Geist
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: 0.875rem
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
  space-3xl: 3rem
---

## Brand & Style

This design system embodies high-velocity software engineering rigor, precision, and technical trust. Designed specifically for an autonomous repository repair agent, the aesthetic bridges the clarity of modern developer interfaces (Linear, GitHub) with the dense utility of advanced IDE tooling.

The interface prioritizes low cognitive friction, exceptional scannability, and high density without clutter. The mood is calm, authoritative, and clinical: operations succeed with subtle confidence, errors are highlighted with surgical accuracy, and code modifications are presented with immaculate contrast and readability. The design movement is **Modern Technical Minimalism** characterized by crisp hairline borders, pure white layered cards on cool architectural backdrops, micro-shadows, and deliberate density.

## Colors

The palette is engineered around an ultra-clean, clinical light mode configured to reduce eye strain during extended debugging and code reviews.

- **Canvas & Backgrounds:**
  - Base canvas: `#F8FAFC` (Cool slate tint, providing crisp separation for white modules).
  - Surface cards & active panels: `#FFFFFF` (Pure white).
  - Secondary/Inset surfaces: `#F1F5F9` (Diff backgrounds, gutters, secondary command trays).
  - Hover states on neutral surfaces: `#E2E8F0` at 50% opacity or `#F8FAFC`.

- **Borders & Dividers:**
  - Subtle borders: `#E2E8F0` (Default 1px container and divider frame).
  - Interactive/Focus borders: `#CBD5E1` for hover; `#2563EB` for active focus rings.

- **Brand & Accent:**
  - Primary Action / Accent: `#2563EB` (Cobalt Blue). Provides unmistakable affordance for primary executions (e.g., "Run Patch", "Create PR").
  - Primary Foreground: `#FFFFFF`.

- **Semantic Signals:**
  - **Success / Added Lines:** `#16A34A` (Emerald 600). Tinted surface: `#F0FDF4`.
  - **Error / Removed Lines:** `#DC2626` (Rose/Red 600). Tinted surface: `#FEF2F2`.
  - **Warning / Pending State:** `#D97706` (Amber 600). Tinted surface: `#FFFBEB`.
  - **Information / Agent Analysis:** `#0284C7` (Sky 600). Tinted surface: `#F0F9FF`.

- **Typography & Neutral Tokens:**
  - Slate 900 (`#0F172A`): Headings, primary text, active status.
  - Slate 600 (`#475569`): Secondary descriptions, metadata keys.
  - Slate 400 (`#94A3B8`): Line numbers, inactive breadcrumbs, placeholders.

## Typography

The typography pairing uses **Geist** for crisp UI control surfaces and **JetBrains Mono** for code, commit hashes, metrics, and diff representations.

Geist delivers tight optical alignment with slightly negative letter spacing across display and heading hierarchies, creating an authoritative, modern tone reminiscent of Linear and Vercel. 

JetBrains Mono delivers legibility across code blocks, git refs, and unified diff views. Line height within code representations is strictly pegged to `1.375rem` (22px) on 13px font sizes to preserve clean vertical alignment across side-by-side or inline diff inspections.

## Layout & Spacing

This design system uses a modular, fluid application shell designed to maximize screen real estate for technical workflows.

- **Workspace Anatomy:**
  - **Left Rail (Persistent / Collapsible):** 240px wide for repository trees, agent active tasks, and repair queues.
  - **Primary Stage:** Fluid canvas hosting the inspectable repair plan, timeline events, or file diff comparisons.
  - **Context Inspector (Slide-over/Fixed panel):** 360px wide containing diagnostic outputs, agent reasoning traces, and AST analysis.
- **Rhythm & Grid:**
  - Layout is governed by a strict 4px/8px incremental base unit.
  - Inner card padding strictly aligns to `space-md` (12px) for high-density tables and `space-xl` (24px) for expansive analytical diff modules.
  - Gutter distances expand from `1rem` on tablet/condensed viewports to `1.5rem` on wide display workstations.

## Elevation & Depth

Visual hierarchy does not rely on heavy drop shadows; instead, it uses crisp, architectural separation with hairline borders (`#E2E8F0`) combined with ultra-soft micro-shadows.

- **Flat Layer (Canvas):** Base background `#F8FAFC`, no elevation.
- **Surface Elevation 1 (Cards, Code Blocks, Nav Bars):**
  - Background: `#FFFFFF`
  - Border: `1px solid #E2E8F0`
  - Shadow: `0 1px 2px 0 rgba(15, 23, 42, 0.04)`
- **Surface Elevation 2 (Dropdowns, Command Menus, Hover States):**
  - Background: `#FFFFFF`
  - Border: `1px solid #CBD5E1`
  - Shadow: `0 4px 6px -1px rgba(15, 23, 42, 0.06), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`
- **Surface Elevation 3 (Floating Overlays, Modal Agent Dialogs):**
  - Background: `#FFFFFF`
  - Border: `1px solid #CBD5E1`
  - Shadow: `0 12px 24px -4px rgba(15, 23, 42, 0.08), 0 4px 8px -2px rgba(15, 23, 42, 0.04)`
- **Inset Depth (Terminal outputs, Diff view canvases):**
  - Background: `#F1F5F9` or `#F8FAFC`
  - Inner subtle border: `inset 0 1px 2px 0 rgba(15, 23, 42, 0.03)`

## Shapes

The design system uses a tight, structured shape language (`roundedness: 1` — base radius of `0.25rem` / 4px, `rounded-md` of `0.375rem` / 6px, and `rounded-lg` of `0.5rem` / 8px).

- **Cards & Primary Modules:** 8px (`rounded-lg`) corner radius, keeping layouts disciplined and professional without feeling bubbly.
- **Interactive Controls (Buttons, Inputs, Selects):** 6px (`rounded-md`) corner radius.
- **Micro-Indicators (Tags, Git SHA pills, Status dots):** 4px (`rounded-sm`) or 9999px (full pill) strictly when indicating live pulse states.

## Components

### Buttons
- **Primary:** Solid `#2563EB` fill, `#FFFFFF` text, subtle inner top highlight (`inset 0 1px 0 rgba(255,255,255,0.2)`), hover background `#1D4ED8`. Active downscale `scale(0.99)`.
- **Secondary:** Surface `#FFFFFF`, border `1px solid #E2E8F0`, text `#0F172A`, micro-shadow. Hover: `#F8FAFC`, border `#CBD5E1`.
- **Destructive:** Surface `#FEF2F2`, border `1px solid #FECACA`, text `#DC2626`. Hover: `#DC2626`, text `#FFFFFF`.
- **Ghost/Icon Button:** Transparent background, text `#64748B`. Hover: `#F1F5F9`, text `#0F172A`.

### Status Badges & Chips
- Structure: 20px height, font: `label-badge`, padding: `0 6px`, border-radius: 4px.
- **Success (Repaired / Verified):** Background `#F0FDF4`, border `1px solid #BBF7D0`, text `#16A34A`. Includes a static 6px solid green dot.
- **Error (Failed / Breaking Change):** Background `#FEF2F2`, border `1px solid #FECDD3`, text `#DC2626`.
- **Processing (Agent Running):** Background `#EFF6FF`, border `1px solid #BFDBFE`, text `#2563EB`. Dot contains a 1.5s pulse animation.
- **Monospace Chip (Branch, Commit SHA):** JetBrains Mono 11px, background `#F1F5F9`, border `1px solid #E2E8F0`, text `#334155`.

### Code & Diff Viewer
- **Container:** Pure `#FFFFFF` card framed by `1px solid #E2E8F0`. Line numbers rendered in `JetBrains Mono` 12px with `#94A3B8` foreground on an inset `#F8FAFC` gutter.
- **Added Line (+):** Full-bleed background `#F0FDF4`, text color `#14532D`, marker `+` highlighted in `#16A34A`, inline diff word highlight `#DCFCE7`.
- **Removed Line (-):** Full-bleed background `#FEF2F2`, text color `#7F1D1D`, marker `-` highlighted in `#DC2626`, inline diff word highlight `#FEE2E2`.
- **Gutter Divider:** 1px vertical hairline in `#E2E8F0`.

### Agent Timeline & Activity Stream
- Continuous vertical spine: 2px wide line in `#E2E8F0`.
- **Nodes:** 18px circular indicator centered on the spine. Completed nodes use `#16A34A` icons; active agent steps use a white disc with a `2px solid #2563EB` ring; pending steps use `#CBD5E1`.
- **Event Card:** Attached to each node, pure white card, padding 12px 16px, displaying agent thought process, tool invocations (e.g., `git apply`, `npm test`), and duration stamps.

### Inputs & Filters
- Background `#FFFFFF`, height 36px, border `1px solid #E2E8F0`, radius 6px.
- Focus state: Border color `#2563EB`, box-shadow `0 0 0 3px rgba(37, 99, 235, 0.12)`.
- Monospace input variant provided for regex queries, branch inputs, and file glob patterns.